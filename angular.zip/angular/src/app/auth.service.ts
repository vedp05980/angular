import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { tap, delay, catchError, map } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private url = 'https://api.unlockfranchise.com/';
  private isAuthenticatedValue = false;
  private headerUpdateSubject = new BehaviorSubject<boolean>(false);
  private sidebarOpen = new BehaviorSubject<boolean>(false);
  headerUpdate$ = this.headerUpdateSubject.asObservable();
  sidebarOpen$ = this.sidebarOpen.asObservable();
  constructor(private http: HttpClient, private router: Router) { }

  login(email: string, password: string): Observable<any> {
    const body = { email, password };
    return this.http.post(this.url + 'user/auth/login', body, {
      headers: {
        'Content-Type': 'application/json',
      },
      observe: 'response',
    }).pipe(
      tap((response: HttpResponse<any>) => {
        const token = response.headers.get('Authorization');
        if (token) {
          this.isAuthenticatedValue = true;
          localStorage.setItem('authToken', token);
          console.log('Token:', token);
        } else {
          console.log('Authorization header not found');
        }
      }),
      map((response: HttpResponse<any>) => response.body)
    );
  }

  toggleSidebar() {
    this.sidebarOpen.next(!this.sidebarOpen.value);
  }

  startTokenExpirationCheck() {
    const token = this.authToken;
    if (!token) return;

    const payload = JSON.parse(atob(token.split('.')[1]));
    const expirationTime = payload.exp * 1000;
    const timeUntilExpiration = expirationTime - Date.now();

    if (timeUntilExpiration > 0) {
      setTimeout(() => {
        this.logout();
        this.router.navigate(['/login']);
      }, timeUntilExpiration);
    } else {
      this.logout();
      this.router.navigate(['/login']);
    }
  }

  get authToken(): string | null {
    return localStorage.getItem('authToken');
  }

  get refreshToken(): string | null {
    return localStorage.getItem('refreshToken');
  }

  isAuthenticated(): boolean {
    return !!this.authToken;
  }

  isAuthenticatedAsync(): Observable<boolean> {
    return of(!localStorage.getItem('authToken')).pipe(delay(1000));
  }

  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    this.isAuthenticatedValue = false;
    this.router.navigate(['/login']);
  }

  signup(obj: any): Observable<any> {
    // const body = { firstName, phoneNumber, email, password };
    return this.http.post(this.url + 'user/auth/create', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  changePassword(obj: any): Observable<any> {
    return this.http.post(this.url + 'user/changePassword', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  updateUser(obj: any, id: number): Observable<any> {
    // const body = { firstName, phoneNumber, email, password };
    return this.http.patch(this.url + `user/updateProfile`, obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  userList(skip: number, limit: number): Observable<any> {
    return this.http.get(this.url + `user/all`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  getUserById(id: number): Observable<any> {
    return this.http.get(this.url + `user/${id}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  activateUserToggle(data: any) {
    return this.http.patch(this.url + 'user/deactivate', data, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  leadList(dateRange: any): Observable<any> {
    return this.http.post(this.url + `lead/all`, dateRange, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  createLead(obj: any): Observable<any> {
    return this.http.post(this.url + 'lead/create', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  updateLead(obj: any, id: number): Observable<any> {
    return this.http.patch(this.url + 'lead/update', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  getLeadById(id: number): Observable<any> {
    return this.http.get(this.url + `lead/${id}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  deleteLead(obj: any): Observable<any> {
    return this.http.delete(this.url + `lead/delete`, {
      body: obj,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  triggerHeaderUpdate() {
    this.headerUpdateSubject.next(true);
  }


  /*  */

  packageList(skip: number, limit: number): Observable<any> {
    return this.http.get(this.url + `package/all?skip=${skip}&limit=${limit}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  createPackage(obj: any): Observable<any> {
    return this.http.post(this.url + 'package/create', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  updatePackage(obj: any, id: number): Observable<any> {
    return this.http.patch(this.url + 'package/update', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  assignPackage(obj: any): Observable<any> {
    return this.http.patch(this.url + 'package/assignPackage', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  getPackageById(id: number): Observable<any> {
    return this.http.get(this.url + `package/${id}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  deletePackage(obj: any): Observable<any> {
    return this.http.delete(this.url + `package/delete`, {
      body: obj,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  franchiseList(skip: number, limit: number): Observable<any> {
    return this.http.get(this.url + `franchise/all`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  addFranchise(obj: any) {
    let formdata: FormData = new FormData();
    formdata.append('logo', obj.logo);
    formdata.append('name', obj.name);
    formdata.append('featured', obj.featured);
    formdata.append('description', obj.description);
    formdata.append('category', obj.category);
    formdata.append('subCategory', obj.subCategory);
    formdata.append('businessInfo', JSON.stringify([obj.businessInfo[0]]));
    obj.gallery.forEach((file: File) => {
      formdata.append('gallery', file);
    });

    return this.http.post<any[]>(this.url + 'franchise/create', formdata, {
      headers: {
        // 'content-type': 'application/json'
      }
    });
  }

  updateFranchise(obj: any, id: number): Observable<any> {
    return this.http.patch(this.url + `franchise/create/${id}`, obj, {
      headers: {
        // 'Content-Type': 'application/json'
      }
    });
  }
  
  deleteFranchise(obj: any): Observable<any> {
    return this.http.delete(this.url + `franchise/delete`, {
      body: obj,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  allFranchiseList(category:any, subCategory:any, featured:any, expLocations:any, investmentRange:any, limit:any, searchTerm:any): Observable<any> {
    return this.http.get(this.url + `franchise/all?category=${category}&subCategory=${subCategory}&featured=${featured}&expLocations=${expLocations}&limit=${limit}&searchTerm=${searchTerm}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  franchisebyId(id:any): Observable<any> {
    return this.http.get(this.url + `franchise/${id}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

}