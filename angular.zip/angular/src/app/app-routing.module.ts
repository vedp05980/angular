import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { ChangePasswordComponent } from './common/change-password/change-password.component';
import { SupermarketFranchiseComponent } from './landing/supermarket-franchise/supermarket-franchise.component';
import { SupermarketThankyouComponent } from './landing/supermarket-thankyou/supermarket-thankyou.component';

const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: localStorage.getItem('authToken') ? 'user' : 'login',
  //   pathMatch: 'full',
  // },
  
  { path: '', loadChildren: () => import('./landing/landing.module').then(m => m.LandingModule) },
  {
    path: 'supermarket-franchise',
    component: SupermarketFranchiseComponent,
  },
  {
    path: 'supermarket-thankyou',
    component: SupermarketThankyouComponent,
  },
  // {
  //   path: '',
  //   redirectTo: 'login',
  //   pathMatch: 'full'
  // },
  {
    path: 'change-password',
    component: ChangePasswordComponent,
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
