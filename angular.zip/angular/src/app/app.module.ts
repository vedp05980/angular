import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth.interceptor';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormElementComponent } from './admin/form-element/form-element.component';
import { TableElementComponent } from './admin/table-element/table-element.component';



import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { DeleteModalComponent } from './admin/modal/delete-modal/delete-modal.component';
import { EditModalComponent } from './admin/modal/edit-modal/edit-modal.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { StackCompareChartComponent } from './admin/shared/stack-compare-chart/stack-compare-chart.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonSharedModule } from './common/common-shared.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ToastrModule } from 'ngx-toastr';
import { CKEditorModule } from 'ckeditor4-angular';
import { ChangePasswordComponent } from './common/change-password/change-password.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SupermarketFranchiseComponent } from './landing/supermarket-franchise/supermarket-franchise.component';
import { SupermarketThankyouComponent } from './landing/supermarket-thankyou/supermarket-thankyou.component';
import { UrlSerializer } from '@angular/router';
import { CustomUrlSerializer } from './shared/custom-url-serializer';
@NgModule({
  declarations: [
    AppComponent,
    FormElementComponent,
    TableElementComponent,
    DeleteModalComponent,
    EditModalComponent,
    StackCompareChartComponent,
    ChangePasswordComponent,
    SupermarketFranchiseComponent,
    SupermarketThankyouComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatSelectModule,
    CKEditorModule,
    MatInputModule,
    CommonSharedModule,
    FormsModule,
    BrowserAnimationsModule,
    HighchartsChartModule,
    HttpClientModule,
    NgxSpinnerModule,
    ToastrModule.forRoot(),
    SlickCarouselModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    {
      provide: UrlSerializer,
      useClass: CustomUrlSerializer
    }
  ],
  bootstrap: [AppComponent],

  exports: [
    MatFormFieldModule,
    MatDialogModule,
    MatSelectModule,
    MatInputModule,
    FormsModule,
    BrowserAnimationsModule,
  ]

})
export class AppModule { }
