import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteModalComponent } from '../../admin/modal/delete-modal/delete-modal.component';
import { AuthService } from '../../auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  connectedUser: any;
  SECRET_KEY = 'unlock_fren_1242';
  isSidebarOpen: boolean = false;
  constructor(public dialog: MatDialog,
    private router: Router,
    private authService: AuthService,
  ) {
    this.authService.sidebarOpen$.subscribe(open => {
      this.isSidebarOpen = open;
    });
  }

  ngOnInit(): void {
    // this.connectedUser = JSON.parse(localStorage.getItem('connectedUser') || '{}');;
    const encrypted = localStorage.getItem('connectedUser');
    if (encrypted) {
      const decryptedData = CryptoJS.AES.decrypt(encrypted, this.SECRET_KEY).toString(CryptoJS.enc.Utf8);
      this.connectedUser = JSON.parse(decryptedData);
      // console.log('Decrypted User Data:', this.connectedUser);
    }
    this.authService.headerUpdate$.subscribe(() => {
      this.reloadHeader(); // React to the update
    });
  }

  openDeleteDialog(): void {
    const dialogRef = this.dialog.open(DeleteModalComponent, {
      width: '600px',
    });
  }
  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('connectedUser');
    this.router.navigate(['/login']);
  }
  gotoProfile() {
    this.router.navigate(['/user/user-profile']);
  }
  gotoPassword() {
    this.router.navigate(['change-password']);
  }
  reloadHeader(): void {
    const encrypted = localStorage.getItem('connectedUser');
    if (encrypted) {
      const decryptedData = CryptoJS.AES.decrypt(encrypted, this.SECRET_KEY).toString(CryptoJS.enc.Utf8);
      this.connectedUser = JSON.parse(decryptedData);
    }
    console.log('Header reloaded');
  }
  toggleSidebar() {
    this.authService.toggleSidebar();
  }
}
