import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { AuthService } from '../../auth.service';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  SECRET_KEY = 'unlock_fren_1242';
  sideFlag: boolean = false;
  activeMenu: string = '';
  isSidebarOpen = false;
  connectedUser: any;
  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    const encrypted = localStorage.getItem('connectedUser');
    if (encrypted) {
      const decryptedData = CryptoJS.AES.decrypt(encrypted, this.SECRET_KEY).toString(CryptoJS.enc.Utf8);
      this.connectedUser = JSON.parse(decryptedData);
      console.log('Decrypted User Data:', this.connectedUser);
    }
    this.authService.sidebarOpen$.subscribe(open => {
      this.isSidebarOpen = open;
    });
  }

  sideDropdown() {
    this.sideFlag = !this.sideFlag;
  }

  openAllLeads() {
    this.setActive('leads');
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['lead']);
    });
  }

  openUserList() {
    this.setActive('users');
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['user/']);
    });    
  }
  openDashboard() {
    this.setActive('dashboard');
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['admin/dashboard']);
    });    
    
  }

  openMyLeads() {
    this.setActive('myleads');    
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['lead/my-leads']);
    });
  }

  openContact() {
    this.setActive('contact');    
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['user/contact']);
    });
  }


  setActive(menu: string) {
    if (this.activeMenu !== menu) {
      console.log(`Setting active menu to: ${menu}`);
      this.activeMenu = menu;
    }
  }
  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('connectedUser');
    this.router.navigate(['/login']);
  }
  openPackage() {
    this.setActive('package');    
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['package/list']);
    });
  }
  addFranchise() {
    this.setActive('franchise');
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['franchise/list']);
    });
  }
}
