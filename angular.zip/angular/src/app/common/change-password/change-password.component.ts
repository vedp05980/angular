import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../auth.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent {
  changePasswordForm: FormGroup;

  constructor(private fb: FormBuilder,
    private authService: AuthService,
    private toastr: ToastrService,
  ) {
    this.changePasswordForm = this.fb.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    })
  }
  getErrorMessage(fieldName: string): string | null {
    const oldPassword = this.changePasswordForm.get('oldPassword')?.value || '';
    const newPassword = this.changePasswordForm.get('newPassword')?.value || '';
    const confirmPassword = this.changePasswordForm.get('confirmPassword')?.value || '';

    // Required field validation
    if (this.changePasswordForm.get(fieldName)?.hasError('required')) {
      return `${this.formatFieldName(fieldName)} is required.`;
    }

    // Minlength validation
    if (this.changePasswordForm.get(fieldName)?.hasError('minlength')) {
      const requiredLength = this.changePasswordForm.get(fieldName)?.errors?.['minlength']?.requiredLength;
      return `${this.formatFieldName(fieldName)} must be at least ${requiredLength} characters long.`;
    }

    // Old password and new password should not match
    if (
      fieldName === 'newPassword' &&
      oldPassword &&
      newPassword &&
      oldPassword === newPassword
    ) {
      return `Old password and new password should not be the same.`;
    }

    // New password and confirm password must match
    if (
      fieldName === 'confirmPassword' &&
      newPassword &&
      confirmPassword &&
      newPassword !== confirmPassword
    ) {
      return `New password and confirm password should same`;
    }

    return null; // No errors
  }
  formatFieldName(fieldName: string): string {
    return fieldName.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());
  }
  cancel() {
    window.history.back();
  }
  onSubmit() {
    let obj = {
      oldPassword: this.changePasswordForm.get('oldPassword')?.value,
      newPassword: this.changePasswordForm.get('newPassword')?.value,
    }
    if (obj.newPassword !== this.changePasswordForm.get('confirmPassword')?.value) return
    console.log('password form', obj)
    this.authService.changePassword(obj).subscribe(
      response => {
        this.toastr.success(response.status.message);
      },
      error => {
        this.toastr.error(error.error.message);
      }
    );
  }
}
