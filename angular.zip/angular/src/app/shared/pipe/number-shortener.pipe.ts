import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numberShortener'
})
export class NumberShortenerPipe implements PipeTransform {

  transform(value: string | number): string {
    if (!value) return '';
    if (typeof value === 'string' && value.includes('-')) {
      const parts = value.split('-');
      return parts.map(val => this.formatNumber(+val)).join(' - ');
    }

    return this.formatNumber(+value);
  }

  private formatNumber(value: number): string {
    if (value >= 1_000_000_000) return (value / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'B';
    if (value >= 1_000_000) return (value / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (value >= 1_000) return (value / 1_000).toFixed(1).replace(/\.0$/, '') + 'K';
    return value.toString();
  }
}
