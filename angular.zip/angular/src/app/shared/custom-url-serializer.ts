import { DefaultUrlSerializer, UrlSerializer, UrlTree } from '@angular/router';

export class CustomUrlSerializer implements UrlSerializer {
  private default = new DefaultUrlSerializer();

  parse(url: string): UrlTree {
    return this.default.parse(url);
  }

  serialize(tree: UrlTree): string {
    let result = this.default.serialize(tree);
    if (!result.endsWith('/') && result !== '/') {
      result += '/';
    }
    return result;
  }
}
