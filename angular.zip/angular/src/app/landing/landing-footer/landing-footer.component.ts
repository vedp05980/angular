import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing-footer',
  templateUrl: './landing-footer.component.html',
  styleUrls: ['./landing-footer.component.scss']
})
export class LandingFooterComponent {
  constructor(private router: Router) { }

  goToCategory(category: string): void {
    this.router.navigate(['/franchises'], { queryParams: { category } });
  }

  gfresh() {
    this.router.navigate([`/franchise/g-fresh-retail-pvt.-ltd.`], {
      state: { id: "67c3381cbfa21442632374fb" },      
    });
  }

  bigdeal() {
    this.router.navigate([`/franchise/bigdeal-supermart`], {
      state: { id: "67c333a6bfa21442632374ec" },      
    });
  }

  houseCure() {
    this.router.navigate([`/franchise/house-of-cure`], {
      state: { id: "67c33a38bfa2144263237502" },      
    });
  }

  ecotika() {
    this.router.navigate([`/franchise/ecotika-india`], {
      state: { id: "67c33d07bfa214426323750f" },      
    });
  }

  delhiChai() {
    this.router.navigate([`/franchise/delhi-chai-cafe`], {
      state: { id: '67c46e41bfa214426323755a' },      
    });
  }

  pepperfry() {
    this.router.navigate([`/franchise/pepperfry`], {
      state: { id: "67dd35331bb9689b3e0e560b" },      
    });
  }

  cafeDurga() {
    this.router.navigate([`/franchise/cafe-durga`], {
      state: { id: '67c339c4bfa21442632374ff' },      
    });
  }

}
