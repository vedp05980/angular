import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandingRoutingModule } from './landing-routing.module';
import { LandingHeaderComponent } from './landing-header/landing-header.component';
import { LandingFooterComponent } from './landing-footer/landing-footer.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { FranchisesComponent } from './franchises/franchises.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FranchiseDetailsComponent } from './franchise-details/franchise-details.component';
import { SupermarketThankyouComponent } from './supermarket-thankyou/supermarket-thankyou.component';
import { NumberShortenerPipe } from '../shared/pipe/number-shortener.pipe';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    LandingHeaderComponent,
    LandingFooterComponent,
    LandingPageComponent,
    FranchisesComponent,
    FranchiseDetailsComponent,
    NumberShortenerPipe,
    AboutComponent,
    ContactComponent,
    PrivacyPolicyComponent
  ],
  imports: [
    CommonModule,
    LandingRoutingModule,
    SlickCarouselModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ]
})
export class LandingModule { }
