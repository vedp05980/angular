import { Component, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { LandingService } from '../landing.service';

@Component({
  selector: 'app-supermarket-franchise',
  templateUrl: './supermarket-franchise.component.html',
  styleUrls: ['./supermarket-franchise.component.scss']
})
export class SupermarketFranchiseComponent {
  @HostListener('window:scroll')
  counters = [
    { targetValue: 1500, currentValue: 0, description: 'Brands' },
    { targetValue: 250, currentValue: 0, description: 'Stores' },
    { targetValue: 60, currentValue: 0, description: 'Cities' },
  ];
  duration = 2000;
  leadForm: FormGroup;

  constructor(private fb: FormBuilder,
    private landingService: LandingService,
    private spinner: NgxSpinnerService,
    private router: Router) {
    this.leadForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
    });
  }

  ngOnInit() {
    this.startAllCounters();
  }

  startAllCounters() {
    this.counters.forEach((counter) => {
      const step = Math.ceil(counter.targetValue / (this.duration / 50)); // Ensure at least 1 increment per step
      const interval = setInterval(() => {
        if (counter.currentValue < counter.targetValue) {
          counter.currentValue += step; // Increment the counter
          if (counter.currentValue >= counter.targetValue) {
            counter.currentValue = counter.targetValue; // Stop at the target value
            clearInterval(interval); // Clear the interval
          }
        }
      }, 50);
    });
  }

  onSubmit() {
    this.spinner.show()
    const obj = {
      name: this.leadForm.value.name,
      // lastName: this.leadForm.value.lastName,
      phoneNumber: this.leadForm.value.phoneNumber,
      email: this.leadForm.value.email,
      category: 'Retail',
      subCategory: 'Grocery & Supermarket',
      remarks: "I'm ready to supermarket franchise",
    }
    console.log('objeect', obj)
    this.landingService.createLead(obj).subscribe(
      response => {
        this.spinner.hide();
        this.leadForm.reset()
        this.router.navigate(['supermarket-thankyou']);
      },
      error => {
        this.spinner.hide();
      }
    );
  }

  gotoTop() {
    window.scroll({ 
      top: 0, 
      left: 0, 
      behavior: 'smooth' 
    });
  }

}
