import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupermarketFranchiseComponent } from './supermarket-franchise.component';

describe('SupermarketFranchiseComponent', () => {
  let component: SupermarketFranchiseComponent;
  let fixture: ComponentFixture<SupermarketFranchiseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SupermarketFranchiseComponent]
    });
    fixture = TestBed.createComponent(SupermarketFranchiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
