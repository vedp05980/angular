import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/auth.service';

interface Franchise {
  _id: string;
  name: string;
  logo: string[];
  category: string;
  subCategory: string;
  featured: boolean;
}
@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent {

  categoryList: { category: string; count: number }[] = [];
  retailList: any[] = [];
  healthList: any[] = [];
  foodList: any[] = [];
  beautyList: any[] = [];
  fashionList: any[] = [];
  businessList: any[] = [];
  homeBasedList: any[] = [];
  educationList: any[] = [];
  supermarketList: any[] = [];
  slides: Franchise[] = [];
  category: any = '';
  subCategory: any = '';
  expLocations: any = '';
  featured: any = '';
  limit: any = '';
  investmentRange: any = '';
  categoryData: any = '';
  searchQuery: string = '';
  selectedCategory: string[] = [];
  categoryForFilter: any;

  constructor(
    private spinner: NgxSpinnerService,
    private authService: AuthService,
    private router: Router,
  ) {
    const state = history.state;
    this.categoryForFilter = state?.category;
  }
  ngOnInit() {
    this.getAllFranchise();
  }

  getAllFranchise(): void {
    this.spinner.show();
    this.authService.allFranchiseList(this.category, this.subCategory, this.featured, this.expLocations, this.investmentRange, this.limit, this.searchQuery).subscribe(
      response => {
        if (response) {
          let data = response?.data?.filter((elem: any) => elem?.category == this.categoryForFilter);
          this.slides = response?.data;
          const categoryCountMap: { [key: string]: number } = {};

          this.slides.forEach((item: any) => {
            const category = item.category;
            categoryCountMap[category] = (categoryCountMap[category] || 0) + 1;
          });

          this.categoryList = Object.entries(categoryCountMap).map(([category, count]) => ({
            category,
            count
          }));
          console.log('categoryList', this.categoryList)
          this.healthList = this.slides.filter((item: any) => item.category === 'Healthcare');
          this.retailList = this.slides.filter((item: any) => item.category === 'Retail');
          this.foodList = this.slides.filter((item: any) => item.category === 'Food & Beverages');
          this.educationList = this.slides.filter((item: any) => item.category === 'Education');
          this.businessList = this.slides.filter((item: any) => item.category === 'Business Services');
          this.beautyList = this.slides.filter((item: any) => item.category === 'Beauty & Grooming');
          this.supermarketList = this.slides.filter((item: any) => item.category === 'supermarket');
          this.homeBasedList = this.slides.filter((item: any) => item.category === 'Home Based Business');
          this.fashionList = this.slides.filter((item: any) => item.category === 'Apparel & Fashion');
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        console.error(error);
      })
  }

  openFranchise(eve: any) {
    this.router.navigate([`/franchise/${eve.url}`], {
      state: { id: eve._id, category: eve?.category },
    });
  }

  openAllFranchise(category: any) {
    this.router.navigate([`/franchises/`], {
      state: { category: category },
    });
  }

  search(): void {
    const queryParams: any = {};
    if (this.searchQuery) {
      queryParams.search = this.searchQuery;
    }
    if (this.categoryData) {
      queryParams.category = this.categoryData;
    }

    this.router.navigate(['/franchises'], { queryParams });
  }
}
