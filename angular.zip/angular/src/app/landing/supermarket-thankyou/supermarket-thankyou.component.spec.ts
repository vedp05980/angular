import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupermarketThankyouComponent } from './supermarket-thankyou.component';

describe('SupermarketThankyouComponent', () => {
  let component: SupermarketThankyouComponent;
  let fixture: ComponentFixture<SupermarketThankyouComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SupermarketThankyouComponent]
    });
    fixture = TestBed.createComponent(SupermarketThankyouComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
