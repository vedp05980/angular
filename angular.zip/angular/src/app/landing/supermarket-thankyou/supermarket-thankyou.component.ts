import { Component } from '@angular/core';

@Component({
  selector: 'app-supermarket-thankyou',
  templateUrl: './supermarket-thankyou.component.html',
  styleUrls: ['./supermarket-thankyou.component.scss']
})
export class SupermarketThankyouComponent {

}
