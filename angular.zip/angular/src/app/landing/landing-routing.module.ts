import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { AuthGuard } from '../auth.guard';
import { FranchisesComponent } from './franchises/franchises.component';
import { FranchiseDetailsComponent } from './franchise-details/franchise-details.component';
import { SupermarketFranchiseComponent } from './supermarket-franchise/supermarket-franchise.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';

const routes: Routes = [
  {
    path: '',
    component: LandingPageComponent,
  },
  {
    path: 'franchises',
    component: FranchisesComponent,
  },
  {
    path: 'franchise/:url',
    component: FranchiseDetailsComponent,
  },
  {
    path: 'supermarket-franchise',
    component: SupermarketFranchiseComponent,
  },
  {
    path: 'about',
    component: AboutComponent,
  },
  {
    path: 'contact',
    component: ContactComponent,
  },
    {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LandingRoutingModule { }


