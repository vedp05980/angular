import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { tap, delay, catchError, map } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LandingService {
  private url = 'https://api.unlockfranchise.com/';
  private isAuthenticatedValue = false;
  private headerUpdateSubject = new BehaviorSubject<boolean>(false);
  headerUpdate$ = this.headerUpdateSubject.asObservable();
  constructor(private http: HttpClient, private router: Router) { }

  login(email: string, password: string): Observable<any> {
    const body = { email, password };
    return this.http.post(this.url + 'user/auth/login', body, {
      headers: {
        'Content-Type': 'application/json',
      },
      observe: 'response',
    }).pipe(
      tap((response: HttpResponse<any>) => {
        const token = response.headers.get('Authorization');
        if (token) {
          this.isAuthenticatedValue = true;
          localStorage.setItem('authToken', token);
          console.log('Token:', token);
        } else {
          console.log('Authorization header not found');
        }
      }),
      map((response: HttpResponse<any>) => response.body)
    );
  }

  startTokenExpirationCheck() {
    const token = this.authToken;
    if (!token) return;

    const payload = JSON.parse(atob(token.split('.')[1]));
    const expirationTime = payload.exp * 1000;
    const timeUntilExpiration = expirationTime - Date.now();

    if (timeUntilExpiration > 0) {
      setTimeout(() => {
        this.logout();
        this.router.navigate(['/login']);
      }, timeUntilExpiration);
    } else {
      this.logout();
      this.router.navigate(['/login']);
    }
  }

  get authToken(): string | null {
    return localStorage.getItem('authToken');
  }

  get refreshToken(): string | null {
    return localStorage.getItem('refreshToken');
  }

  isAuthenticated(): boolean {
    return !!this.authToken;
  }

  isAuthenticatedAsync(): Observable<boolean> {
    return of(!localStorage.getItem('authToken')).pipe(delay(1000));
  }

  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    this.isAuthenticatedValue = false;
    this.router.navigate(['/login']);
  }

  signup(obj: any): Observable<any> {
    // const body = { firstName, phoneNumber, email, password };
    return this.http.post(this.url + 'user/auth/create', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  updateUser(obj: any, id: number): Observable<any> {
    // const body = { firstName, phoneNumber, email, password };
    return this.http.patch(this.url + `user/updateProfile`, obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  userList(skip: number, limit: number): Observable<any> {
    return this.http.get(this.url + `user/all?skip=${skip}&limit=${limit}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  getUserById(id: number): Observable<any> {
    return this.http.get(this.url + `user/${id}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  activateUserToggle(data:any) {
    return this.http.patch(this.url + 'user/deactivate', data,{
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  leadList(skip: number, limit: number): Observable<any> {
    return this.http.get(this.url + `lead/all?skip=${skip}&limit=${limit}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  createLead(obj: any): Observable<any> {
    return this.http.post(this.url + 'lead/createFromWebsite', obj, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  
  triggerHeaderUpdate() {
    this.headerUpdateSubject.next(true);
  }
  
}