import { Component } from '@angular/core';

@Component({
  selector: 'app-landing-header',
  templateUrl: './landing-header.component.html',
  styleUrls: ['./landing-header.component.scss']
})
export class LandingHeaderComponent {

  showMenu: boolean = false;

  showMenuClick(){
    this.showMenu = !this.showMenu;
  }

}
