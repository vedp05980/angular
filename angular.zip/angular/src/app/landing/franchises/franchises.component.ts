import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-franchises',
  templateUrl: './franchises.component.html',
  styleUrls: ['./franchises.component.scss']
})
export class FranchisesComponent {
  searchQuery: string = '';
  franchiseList: any[] = [];
  category: any = '';
  subCategory: any = '';
  featured: any = '';
  expLocations: any = '';
  investmentRange: any = '';
  limit: any = '';
  categoryList: string[] = [];
  categoryListOrg: string[] = [];
  selectedCategory: string[] = [];
  searchTerm: any = '';
  categoryForFilter: any;
  page: number = 1;

  expansionLocations = [
    {
      region: "Central",
      states: [
        { label: "Bihar", value: "bihar" },
        { label: "Chhattisgarh", value: "chhattisgarh" },
        { label: "Jharkhand", value: "jharkhand" },
        { label: "Madhya Pradesh", value: "madhya-pradesh" },
      ],
    },
    {
      region: "East",
      states: [
        { label: "Arunachal Pradesh", value: "arunachal-pradesh" },
        { label: "Assam", value: "assam" },
        { label: "Manipur", value: "manipur" },
        { label: "Meghalaya", value: "meghalaya" },
        { label: "Mizoram", value: "mizoram" },
        { label: "Nagaland", value: "nagaland" },
        { label: "Odisha", value: "odisha" },
        { label: "Sikkim", value: "sikkim" },
        { label: "Tripura", value: "tripura" },
        { label: "West Bengal", value: "west-bengal" },
      ],
    },
    {
      region: "North",
      states: [
        { label: "Delhi", value: "delhi" },
        { label: "Haryana", value: "haryana" },
        { label: "Himachal Pradesh", value: "himachal-pradesh" },
        { label: "Jammu and Kashmir", value: "jammu-kashmir" },
        { label: "Punjab", value: "punjab" },
        { label: "Uttar Pradesh", value: "uttar-pradesh" },
        { label: "Uttarakhand", value: "uttarakhand" },
      ],
    },
    {
      region: "South",
      states: [
        { label: "Andhra Pradesh", value: "andhra-pradesh" },
        { label: "Karnataka", value: "karnataka" },
        { label: "Kerala", value: "kerala" },
        { label: "Tamil Nadu", value: "tamil-nadu" },
        { label: "Telangana", value: "telangana" },
      ],
    },
    {
      region: "Union Territories",
      states: [
        { label: "Andaman and Nicobar", value: "andaman-nicobar" },
        { label: "Chandigarh", value: "chandigarh" },
        { label: "Daman and Diu", value: "daman-diu" },
        { label: "Lakshadweep", value: "lakshadweep" },
        { label: "Pondicherry", value: "pondicherry" },
      ],
    },
    {
      region: "West",
      states: [
        { label: "Goa", value: "goa" },
        { label: "Gujarat", value: "gujarat" },
        { label: "Maharashtra", value: "maharashtra" },
        { label: "Rajasthan", value: "rajasthan" },
      ],
    },
  ];
  selectedLocation: any = '';

  investmentRanges = [
    '₹0 - ₹1,00,000',
    '₹1,00,000 - ₹5,00,000',
    '₹5,00,000 - ₹10,00,000',
  ];
  badgeValues: Record<string, number> = {
    '₹0 - ₹1,00,000': 15,
    '₹1,00,000 - ₹5,00,000': 30,
    '₹5,00,000 - ₹10,00,000': 10,
  };
  selectedInvestmentRange = this.investmentRanges[0];

  constructor(
    private spinner: NgxSpinnerService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    // this.authService.allFranchiseList(this.selectedCategory, this.subCategory, this.featured, this.selectedLocation, this.investmentRange, this.limit, this.searchQuery).subscribe(
    //   response => {
    //     if (response) {
    //       this.franchiseList = response.data;
    //       const categories = this.franchiseList.map((item: any) => item.category);
    //       this.categoryList = Array.from(new Set(categories));
    //       console.log('category list', this.categoryList)
    //       this.spinner.hide();
    //     }
    //   },
    //   (error) => {
    //     this.spinner.hide();
    //     console.error(error);
    //   })

    const state = history.state;
    this.categoryForFilter = state?.category;
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['category']) {
        // Convert category param to array if it's a string (e.g., "Food,Beverages")
        const categoryParam = params['category'];
        this.selectedCategory = categoryParam.includes(',')
          ? categoryParam.split(',')
          : [categoryParam];
      } else {
        this.selectedCategory = []; // fallback default
      }

      if (params['search']) {
        this.searchQuery = params['search'];
      }

      // Call once after setting categories and search query
      this.getAllFranchise();
      this.getCategory();
    });
  }

  selectCategory(category: string): void {
    const index = this.selectedCategory.indexOf(category);
    if (index === -1) {
      this.selectedCategory.push(category); // add
    } else {
      this.selectedCategory.splice(index, 1); // remove
    }

    this.getAllFranchiseCategoryWise();
  }

  selectLocation(location: any): void {
    this.selectedLocation = location;
    this.getAllFranchise()
  }

  showMoreCategories(): void {
    // Add logic to load more categories or expand the list dynamically.
    alert('Load more categories feature coming soon!');
  }



  getBadgeValue(range: string): number {
    return this.badgeValues[range] || 0; // Ensure it works for valid ranges
  }

  onInvestmentRangeChange(selectedRange: string): void {
    this.selectedInvestmentRange = selectedRange;
    this.getAllFranchise()
  }

  getAllFranchise(): void {
    this.franchiseList = [];
    this.spinner.show();
    this.authService.allFranchiseList(this.selectedCategory, this.subCategory, this.featured, this.selectedLocation, this.selectedInvestmentRange, this.limit, this.searchQuery).subscribe(
      response => {
        if (response) {
          if (this.categoryForFilter) {
            const data = response?.data?.filter((elem: any) => elem?.category == this.categoryForFilter);
            this.franchiseList = data;
            this.selectedCategory?.push(this.categoryForFilter)
          }
          else {
            this.franchiseList = response?.data;
          }
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        console.error(error);
      })
  }

  getCategory(): void {
    this.categoryList = [];
    this.spinner.show();
    this.authService.allFranchiseList(this.selectedCategory, this.subCategory, this.featured, this.selectedLocation, this.selectedInvestmentRange, this.limit, this.searchQuery).subscribe(
      response => {
        if (response) {
          let list = response?.data;
          const categories = list?.map((item: any) => item.category);
          this.categoryList = Array.from(new Set(categories));
          this.categoryListOrg = this.categoryList;
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        console.error(error);
      })
  }

  getAllFranchiseCategoryWise(): void {
    this.franchiseList = [];
    this.spinner.show();
    this.authService.allFranchiseList(this.selectedCategory, this.subCategory, this.featured, this.selectedLocation, this.selectedInvestmentRange, this.limit, this.searchQuery).subscribe(
      response => {
        if (response) {
          if (this.categoryForFilter) {
            const data = response?.data?.filter((elem: any) => elem?.category == this.categoryForFilter);
            this.franchiseList = data;
          }
          else {
            this.franchiseList = response?.data;
          }
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        console.error(error);
      })
  }

  openFranchise(eve: any) {
    this.router.navigate([`/franchise/${eve.url}`], {
      state: { id: eve._id, category: eve?.category },
    });
  }

  // Filter category
  filterCategory(searchValue: any){
    let value = searchValue?.value;
    const search = value.toLowerCase();
    const catList = [...this.categoryListOrg];
    let newList = catList?.filter(item =>
      item.toLowerCase().includes(search)
    );
    this.categoryList = newList;
  }


}
