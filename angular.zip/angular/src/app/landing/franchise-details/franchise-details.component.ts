import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-franchise-details',
  templateUrl: './franchise-details.component.html',
  styleUrls: ['./franchise-details.component.scss']
})
export class FranchiseDetailsComponent {

  franchiseData: any;
  franchiseList: any[] = [];
  franchiseListOrg: any[] = [];
  slides: any = [];
  category: any = '';
  subCategory: any = '';
  expLocations: any = '';
  featured: any = '';
  investmentRange: any = '';
  limit: any = 12;
  searchQuery: any = '';
  slideConfig = {
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 3000,
    dots: false,
    infinite: false,
    arrows: true,
    prevArrow: '<button type="button" class="slick-prev">❮</button>',
    nextArrow: '<button type="button" class="slick-next">❯</button>'
  };
  slickInit(event: any) {
    console.log('Slick initialized:', event);
  }

  breakpoint(event: any) {
    console.log('Breakpoint hit:', event);
  }

  afterChange(event: any) {
    console.log('After change:', event);
  }

  beforeChange(event: any) {
    console.log('Before change:', event);
  }

  trackBySlide(index: number, slide: any) {
    return slide.img; // Track by the unique 'img' property
  }

  categoryForFilter: any;

  constructor(private spinner: NgxSpinnerService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    const state = history.state;
    const id = state?.id;
    this.categoryForFilter = state?.category;
    this.getSingleFranchise(id)

    this.route.params.subscribe(params => {
      const id = params['id'];
      this.getSingleFranchise(id)
    });
  }

  ngOnInit() {
    this.getAllFranchise();
  }

  previousId: any;
  ngDoCheck(): void {
    const state = history.state;
    const currentId = state?.id;

    if (currentId && currentId !== this.previousId) {
      this.previousId = currentId;
      this.getSingleFranchise(currentId);
    }
  }

  fId: any;
  getSingleFranchise(id: any): void {
    this.spinner.show();
    this.fId = id;
    this.authService.franchisebyId(this.fId).subscribe(
      response => {
        if (response) {
          this.franchiseData = response.data;
          this.franchiseList = [...this.franchiseListOrg];
          let tempList = this.franchiseList?.filter((elem: any) => elem?._id != this.franchiseData?._id);
          this.franchiseList = tempList;
          this.slides = this.franchiseData?.gallery;
          console.log('franchise data', this.slides)
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        console.error(error);
      })
  }

  getAllFranchise(): void {
    this.spinner.show();
    this.authService.allFranchiseList(this.category, this.subCategory, this.featured, this.expLocations, this.investmentRange, this.limit, this.searchQuery).subscribe(
      response => {
        if (response) {
          let data = response?.data?.filter((elem: any) => elem?.category == this.categoryForFilter);
          this.franchiseList = data;
          this.franchiseListOrg = data;
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        console.error(error);
      })
  }

  openFranchise(eve: any) {
    this.router.navigate([`/franchise/${eve.url}`], {
      state: { id: eve._id },
    });
  }

}